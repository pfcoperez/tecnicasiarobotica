#! /usr/bin/python
# -*- coding: utf-8 -*- 

#    This file is part of PyNavegacion.
#
#    PyNavegacion is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    Foobar is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
#
# Author: Pablo Francisco Pérez Hidalgo (pfcoperez@gmail.com)
from pyrobot.brain import Brain  
from Perceptron import *

import math
   

class NavegaPerceptron(Brain):  

   def setup(self):
      #self.flag = True
      self.vt = 0.5 #Velocidad de translación
      self.distMin = 0.4 #Distancia del robot al objetivo para que se considere
                         # que este ha llegado a la meta.
      #self.pesos = [-0.12263975664466931, 5.9507638709774673, 1.9550886926617097, 0.5912843710976724, -0.78598345123621127, -2.7771039175939292, 0.4238569825493278, -4.5882816210533681, 2.2345860872607699]
      #self.pesos = [2.4421862810459318, -16.410087333622634, -1.3822468303372606, 1.0629425460691442, -29.470909907447457, 20.42554055569753, -7.317308583709675, -7.7834220345048575, 18.141202716341649]      
      #self.pesos = [-55.238185084388718, -27.198712964062842, 54.735472686038904, 9.9457125532332906, -23.08386652847576, -9.6635070299131058, -29.37163914610084, 54.154379175631007, -29.271769952212647]
      #self.pesos = [-55.238185084388718, -27.198712964062842, 54.735472686038904, 9.9457125532332906, -23.08386652847576, -9.6635070299131058, -29.37163914610084, 54.154379175631007, -29.271769952212647]
      self.pesos = 
      #Pares ORIGEN-DESTINO para pruebas:
      #self.testPath = [((0.30,0.30,0),(2.80,2.80,0)),((2.80,0.70,0),(0.60,2.0,0)),((1.6,0.3,0),(1.84,2.9,0)),((2.9,1.75,0),(0.55,1.75,0))]
      self.testPath = [((0.30,0.30,0),(4.5,2.8,0))]
      #Prepara primer cálculo de fitting
      self.npath = 0;
      
      self.posInicial = self.robot.simulation[0].getPose(0)
      #self.posInicial = (self.testPath[self.npath][0][0], self.testPath[self.npath][0][1], self.testPath[self.npath][0][2])
      #self.robot.simulation[0].setPose(0,self.posInicial[0],self.posInicial[1],self.posInicial[2])
      self.calculadorNeuronal = PerceptronMonocapa(self.pesos,w2)

   def calculaPos(self):
      x = self.posInicial[0] - self.robot.y #Conocimiento del robot...
      y = self.posInicial[1] + self.robot.x #... sobre su posición.
      t = self.posInicial[2] + self.robot.th
      return (x, y, t)

   def step(self):
      if self.robot.stall == 1:
         print "CHOQUE¡¡¡¡¡"
         self.engine.pleaseStop()
      else:
         x, y, t = self.calculaPos()
         distancia = +math.sqrt((x-self.testPath[self.npath][1][0])**2+(y-self.testPath[self.npath][1][1])**2)
            #print "Distancia a objetivo> "  + str(distancia)
            #print "Pos = (" + str(x) + ", " + str(y) + ")  Obj = (" + str(self.testPath[self.npath][1][0]) + ", " + str(self.testPath[self.npath][1][1]) + ")"
         if distancia <= self.distMin: 
            print "Objetivo Alcanzado> Origen->" + str(self.testPath[self.npath][0][0:2]) + " Destino->" + str(self.testPath[self.npath][1][0:2])
            self.engine.pleaseStop()
         else: #Utiliza red neuronal para decidir giro
            teta = t-(360.0/(2.0*math.pi))*math.atan2((self.testPath[self.npath][1][1]-y),(self.testPath[self.npath][1][0]-x))
            #print "Theta: " + str(teta) + "º"; 
            sensores = [self.robot.sonar[0][i].distance() for i in range(0,8)]
            #sensoresNorm = sensores
            sensoresNorm = [sensores[i]/max(sensores) for i in range(0,8)]
            velGiro = self.calculadorNeuronal.transferencia(sensoresNorm+[teta/360.0]);
            #print "V GIRO Neuronal: " + str(velGiro)
            #print velGiro
            #velGiro = 0.9*velGiro #Así evito giros muy bruscos
            self.robot.move(self.vt, velGiro)

def INIT(engine):  
   assert (engine.robot.requires("range-sensor") and
           engine.robot.requires("continuous-movement"))
   return NavegaPerceptron('NavegaPerceptron', engine)  

